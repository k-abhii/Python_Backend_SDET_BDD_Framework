class ApiResources:
    addBook = '/Library/Addbook.php'
    deleteBook = '/Library/DeleteBook.php'
    getBookAuthor = ''
